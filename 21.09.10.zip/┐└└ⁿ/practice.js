if (true) {
  var x = 3;
}

console.log(x);
